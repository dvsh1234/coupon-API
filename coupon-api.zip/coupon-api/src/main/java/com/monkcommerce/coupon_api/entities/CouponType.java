package com.monkcommerce.coupon_api.entities;

public enum CouponType {
    BXGY, CART_WISE, PRODUCT_WISE

}